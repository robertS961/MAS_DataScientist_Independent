
class globe:
    edges = []
    prev = ""