# ---- NEW BLOCK ---- # 
#CODE HERE
# Enhanced Plotly visualization pipeline for dataset.csv
# - Improves interactivity, visuals, and layout (dark mode, large charts, non-overlapping controls/legends)
# - Handles NaNs, imputes medians, computes novelty, fits a downloads model, performs citation reconciliation,
#   and runs a metadata audit.
# - Adds detailed, educational narratives integrated into the generated HTML report (introduction, per-figure explanation, conclusion).
# - Produces output.html with each Plotly figure embedded (include_plotlyjs='cdn' per div).
#
# Requirements: pandas, numpy, scikit-learn, plotly
# Save as a .py and run in an environment where dataset.csv is present.
# Produces output.html in the working directory.

import math
import os
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error
import plotly.graph_objects as go
import plotly.express as px
import plotly.io as pio

# --------------------------
# Load & preprocess
# --------------------------
df = pd.read_csv("dataset.csv")

expected_cols = [
    "Conference", "Year", "Title", "DOI", "Link", "FirstPage", "LastPage", "PaperType",
    "Abstract", "AuthorNames-Deduped", "AuthorNames", "AuthorAffiliation", "InternalReferences",
    "AuthorKeywords", "AminerCitationCount", "CitationCount_CrossRef", "PubsCited_CrossRef",
    "Downloads_Xplore", "Award", "GraphicsReplicabilityStamp"
]
for c in expected_cols:
    if c not in df.columns:
        print(f"Warning: expected column '{c}' not found — continuing without it.")

df = df.copy()

# Numeric median imputation
numeric_cols = ["FirstPage", "LastPage", "AminerCitationCount", "CitationCount_CrossRef",
                "PubsCited_CrossRef", "Downloads_Xplore"]
for col in numeric_cols:
    if col in df.columns:
        median_val = float(df[col].median(skipna=True))
        df[col] = df[col].fillna(median_val)

# Text columns fill
text_cols = ["Title", "Abstract", "AuthorKeywords"]
for col in text_cols:
    if col in df.columns:
        df[col] = df[col].fillna("")

# Derived PageCount (robust)
if ("FirstPage" in df.columns) and ("LastPage" in df.columns):
    df["PageCount"] = (df["LastPage"] - df["FirstPage"] + 1).replace([np.inf, -np.inf], np.nan)
    df["PageCount"] = df["PageCount"].mask(df["PageCount"] <= 0, np.nan)
    page_median = float(df["PageCount"].median(skipna=True) if not df["PageCount"].dropna().empty else 1.0)
    df["PageCount"] = df["PageCount"].fillna(page_median)
else:
    df["PageCount"] = 1.0

# Age and per-year rates
max_year_in_data = int(df["Year"].max())
df["AgeYears"] = (max_year_in_data - df["Year"]) + 1
df["AgeYears"] = df["AgeYears"].clip(lower=1)
df["CitesPerYear"] = df["CitationCount_CrossRef"].astype(float) / df["AgeYears"]

# Log targets
df["log_downloads"] = np.log1p(df["Downloads_Xplore"].astype(float))
df["log_cites"] = np.log1p(df["CitationCount_CrossRef"].astype(float))

# Combined text
df["title_abstract"] = (df.get("Title", "").fillna("") + " . " + df.get("Abstract", "").fillna("")).astype(str)

# --------------------------
# 1) Novelty computation (TF-IDF + SVD, novelty relative to previous 3 years)
# --------------------------
tfidf = TfidfVectorizer(max_features=6000, ngram_range=(1, 2), stop_words="english")
X_tfidf = tfidf.fit_transform(df["title_abstract"].values)

svd = TruncatedSVD(n_components=100, random_state=42)
X_red = svd.fit_transform(X_tfidf)
df_red = pd.DataFrame(X_red, index=df.index)

novelty_scores = np.full(len(df), np.nan)
years = sorted(df["Year"].unique())
indices_by_year = {y: df.index[df["Year"] == y].tolist() for y in years}

for idx, row in df.iterrows():
    y = int(row["Year"])
    prev_years = [yr for yr in range(y - 3, y) if yr in indices_by_year]
    prev_idx = []
    for py in prev_years:
        prev_idx.extend(indices_by_year.get(py, []))
    vec = df_red.loc[idx].values.reshape(1, -1)
    if len(prev_idx) >= 5:
        centroid = df_red.loc[prev_idx].mean(axis=0).values.reshape(1, -1)
    else:
        centroid = df_red.mean(axis=0).values.reshape(1, -1)
    cos = cosine_similarity(vec, centroid)[0][0]
    novelty = 1.0 - float(np.clip(cos, -1.0, 1.0))
    novelty_scores[idx] = novelty

nov_min, nov_max = np.nanmin(novelty_scores), np.nanmax(novelty_scores)
if nov_max - nov_min > 0:
    novelty_norm = (novelty_scores - nov_min) / (nov_max - nov_min)
else:
    novelty_norm = np.zeros_like(novelty_scores)
df["novelty_score"] = novelty_norm

# Quick linear check (for annotation)
mask_valid = df["CitesPerYear"].notna() & df["novelty_score"].notna()
if mask_valid.sum() >= 5:
    lr = LinearRegression()
    lr.fit(df.loc[mask_valid, ["novelty_score"]], df.loc[mask_valid, "CitesPerYear"])
    lr_coef = lr.coef_[0]
    lr_intercept = lr.intercept_
else:
    lr_coef = None
    lr_intercept = None

# --------------------------
# 2) Downloads attraction model (RandomForest) with title SVD components
# --------------------------
svd_title = TruncatedSVD(n_components=10, random_state=42)
X_title_tfidf = tfidf.transform(df["Title"].values)
X_title_comp = svd_title.fit_transform(X_title_tfidf)

feat_df = pd.DataFrame({
    "PageCount": df["PageCount"],
    "CitationCount_CrossRef": df["CitationCount_CrossRef"],
    "CitesPerYear": df["CitesPerYear"],
    "novelty_score": df["novelty_score"],
    "Year": df["Year"],
})
for i in range(X_title_comp.shape[1]):
    feat_df[f"title_comp_{i}"] = X_title_comp[:, i]
feat_df = feat_df.fillna(feat_df.median())

median_year = int(df["Year"].median())
train_mask = df["Year"] <= median_year
X_train = feat_df.loc[train_mask].values
y_train = df.loc[train_mask, "log_downloads"].values
X_test = feat_df.loc[~train_mask].values
y_test = df.loc[~train_mask, "log_downloads"].values

rf = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)
feature_names = feat_df.columns.tolist()
importances = rf.feature_importances_
feat_imp_df = pd.DataFrame({"feature": feature_names, "importance": importances}).sort_values("importance", ascending=False)

# Predictions
y_pred_all = rf.predict(feat_df.values)
# Evaluate on train/test (if test not empty)
r2_train = rf.score(X_train, y_train) if len(X_train) > 0 else np.nan
r2_test = rf.score(X_test, y_test) if len(X_test) > 0 else np.nan
mae_test = mean_absolute_error(y_test, rf.predict(X_test)) if len(X_test) > 0 else np.nan

# --------------------------
# 3) Cross-source reconciliation
# --------------------------
df["aminer"] = df["AminerCitationCount"].astype(float)
df["crossref"] = df["CitationCount_CrossRef"].astype(float)
df["citation_diff"] = df["aminer"] - df["crossref"]
df["citation_mean"] = (df["aminer"] + df["crossref"]) / 2.0
mean_diff = float(df["citation_diff"].mean())
std_diff = float(df["citation_diff"].std(ddof=0) if not math.isnan(df["citation_diff"].std()) else 0.0)
df["cit_diff_outlier"] = (df["citation_diff"].abs() > 3 * std_diff) if std_diff > 0 else False

# --------------------------
# 4) Metadata audit
# --------------------------
anomalies = pd.DataFrame(index=df.index)
anomalies["last_lt_first"] = (df["LastPage"] < df["FirstPage"])
anomalies["missing_title"] = df["Title"].isna() | (df["Title"].str.strip() == "")
anomalies["missing_abstract"] = df["Abstract"].isna() | (df["Abstract"].str.strip() == "")
anomalies["missing_keywords"] = df["AuthorKeywords"].isna() | (df["AuthorKeywords"].str.strip() == "")
anomalies["missing_doi"] = df["DOI"].isna() | (df["DOI"].str.strip() == "")
df["dl_z"] = (df["Downloads_Xplore"] - df["Downloads_Xplore"].mean()) / max(1e-9, df["Downloads_Xplore"].std())
df["cit_z"] = (df["CitationCount_CrossRef"] - df["CitationCount_CrossRef"].mean()) / max(1e-9, df["CitationCount_CrossRef"].std())
anomalies["high_downloads"] = df["dl_z"].abs() > 3.0
anomalies["high_citations"] = df["cit_z"].abs() > 3.0
anomaly_counts = anomalies.sum(axis=0).sort_values(ascending=False)
top_conf = df["Conference"].value_counts().nlargest(12).index.tolist()
df_top_conf = df[df["Conference"].isin(top_conf)].copy()
pivot = pd.DataFrame(index=top_conf)
for col in anomalies.columns:
    pivot[col] = df_top_conf.groupby("Conference").apply(lambda g: anomalies.loc[g.index, col].sum()).reindex(top_conf).fillna(0)
pivot = pivot.fillna(0)

# --------------------------
# Plotly global layout helper
# --------------------------
pio.templates["my_dark"] = pio.templates["plotly_dark"]

def base_layout(title_text="", height=760, width=1350, legend_orientation="h", top_margin=200, right_margin=220):
    return dict(
        template="plotly_dark",
        height=height,
        width=width,
        margin=dict(l=80, r=right_margin, t=top_margin, b=120),
        title=dict(text=title_text, font=dict(size=22, color="#FFFFFF"), x=0.01, xanchor="left"),
        paper_bgcolor="#0b0f13",
        plot_bgcolor="#0b0f13",
        legend=dict(orientation=legend_orientation, y=-0.28, x=0.5, xanchor="center", font=dict(size=12)),
    )

# --------------------------
# Figure 1: Novelty vs CitesPerYear
# --------------------------
fig1 = go.Figure()

# Robust y-axis cap to avoid blank/overscaling due to large outliers:
cites_y = df["CitesPerYear"].fillna(0).values
y_cap = max(1.0, np.percentile(cites_y, 98))  # use 98th percentile as upper display cap
y_axis_max = float(y_cap * 1.15)

fig1.add_trace(go.Scatter(
    x=df["novelty_score"],
    y=df["CitesPerYear"],
    mode="markers",
    marker=dict(size=9, color=df["Downloads_Xplore"], colorscale="Viridis", showscale=True,
                colorbar=dict(title="Downloads", len=0.5, x=1.03)),
    text=df["Title"],
    hovertemplate=(
        "<b>%{text}</b><br><br>"
        "Year: %{customdata[0]}<br>"
        "Novelty: %{x:.3f}<br>"
        "Cites/yr: %{y:.2f}<br>"
        "Downloads: %{marker.color}<extra></extra>"
    ),
    customdata=np.stack((df["Year"],), axis=-1),
    name="Papers"
))

# Trend line (linear fit) if available
if lr_coef is not None:
    xs = np.linspace(0.0, 1.0, 200)
    ys = lr_coef * xs + lr_intercept
    fig1.add_trace(go.Scatter(x=xs, y=ys, mode="lines", line=dict(color="#00CC96", width=3), name="Linear trend"))

# Binned averages (bar) - hidden by default
bins = np.linspace(0.0, 1.0, 11)
bin_idx = np.digitize(df["novelty_score"], bins)
binned_df = pd.DataFrame({"bin": bin_idx, "novelty": df["novelty_score"], "cites": df["CitesPerYear"]})
bin_stats = binned_df.groupby("bin").agg(n=("cites", "count"), novelty_mean=("novelty", "mean"),
                                         cites_mean=("cites", "mean")).reset_index().dropna()
fig1.add_trace(go.Bar(
    x=bin_stats["novelty_mean"],
    y=bin_stats["cites_mean"],
    marker_color="#FF6361",
    name="Binned mean (novelty bins)",
    visible=False,
    opacity=0.95,
    hovertemplate="Novelty bin center: %{x:.3f}<br>Mean Cites/yr: %{y:.2f}<extra></extra>"
))

# Updatemenu: toggle views (scatter + trend) vs binned
fig1.update_layout(
    updatemenus=[dict(
        type="buttons",
        direction="left",
        showactive=True,
        x=0.01, xanchor="left",
        y=1.26, yanchor="top",
        pad={"r": 10, "t": 10},
        bgcolor="rgba(255,255,255,0.06)",
        bordercolor="#222222",
        active=0,
        buttons=[
            dict(label="Scatter",
                 method="update",
                 args=[{"visible": [True, True, False]}, {"title": "Novelty vs Citations-per-Year — Scatter"}]),
            dict(label="Binned averages",
                 method="update",
                 args=[{"visible": [False, False, True]}, {"title": "Novelty vs Citations-per-Year — Binned averages"}]),
        ]
    )]
)

fig1.update_layout(base_layout(title_text="1) Topic-Innovation: Novelty vs Citations per Year", top_margin=200))
# Set axes and ranges explicitly to avoid blank visualization
fig1.update_xaxes(title_text="Novelty (0-1)", range=[0.0, 1.0], zeroline=False)
fig1.update_yaxes(title_text="Citations per year", range=[0.0, y_axis_max], zeroline=False)

# Explanation annotation above plot but inside available header space
fig1.add_annotation(dict(
    x=0.01, y=1.20, xref="paper", yref="paper", showarrow=False,
    text=("Each point = paper. Novelty is semantic distance to prior work (3-year window). "
          "Color encodes Downloads. Use the buttons above the plot (not overlapping the plot) to switch views."),
    font=dict(size=12, color="#dddddd"), align="left"
))

# --------------------------
# Figure 2: Downloads attraction model
# --------------------------
fig2 = go.Figure()
top_feats = feat_imp_df.head(12)
fig2.add_trace(go.Bar(
    x=top_feats["importance"][::-1],
    y=top_feats["feature"][::-1],
    orientation="h",
    marker=dict(color=px.colors.sequential.Plasma_r[:len(top_feats)][::-1]),
    hovertemplate="%{y}: importance %{x:.4f}<extra></extra>",
    name="Feature importance"
))

# Predicted vs actual (hidden)
fig2.add_trace(go.Scatter(
    x=df["log_downloads"],
    y=y_pred_all,
    mode="markers",
    marker=dict(size=8, color=df["Year"], colorscale="Plasma", showscale=True,
                colorbar=dict(title="Year", len=0.5, x=1.03)),
    visible=False,
    text=df["Title"],
    hovertemplate="<b>%{text}</b><br>Log(downloads): %{x:.3f}<br>Predicted: %{y:.3f}<extra></extra>",
    name="Predicted vs Actual"
))

# Identity line for predicted vs actual (hidden)
minv = min(df["log_downloads"].min(), float(y_pred_all.min()))
maxv = max(df["log_downloads"].max(), float(y_pred_all.max()))
if math.isfinite(minv) and math.isfinite(maxv) and maxv > minv:
    fig2.add_trace(go.Scatter(x=[minv, maxv], y=[minv, maxv], mode="lines", line=dict(color="#00CC96", dash="dash"),
                              name="Ideal (y=x)", visible=False))

# Dropdown to toggle importance vs predicted->actual
fig2.update_layout(
    updatemenus=[dict(
        type="buttons",
        direction="left",
        showactive=True,
        x=0.01, xanchor="left",
        y=1.26, yanchor="top",
        bgcolor="rgba(255,255,255,0.06)",
        bordercolor="#222222",
        pad={"r": 10, "t": 6},
        buttons=[
            dict(label="Feature importances",
                 method="update",
                 args=[{"visible": [True, False, False]}, {"title": "Downloads Attraction Model — Feature importances"}]),
            dict(label="Predicted vs Actual",
                 method="update",
                 args=[{"visible": [False, True, True]}, {"title": "Downloads Attraction Model — Predicted vs Actual"}]),
        ]
    )]
)

fig2.update_layout(base_layout(title_text="2) Downloads Attraction Model", top_margin=200))
fig2.update_xaxes(title_text="Importance / Log(downloads)")
fig2.update_yaxes(title_text="Feature" if True else "Predicted value")

# Add model performance annotation (train/test)
perf_text = f"Train R²: {r2_train:.3f}" if not math.isnan(r2_train) else "Train R²: NA"
if not math.isnan(r2_test):
    perf_text += f" | Test R²: {r2_test:.3f} | Test MAE (log): {mae_test:.3f}"
fig2.add_annotation(dict(x=0.99, y=1.18, xref="paper", yref="paper", showarrow=False,
                         text=perf_text, font=dict(size=12, color="#cfe8d6"), align="right"))

fig2.add_annotation(dict(x=0.01, y=1.20, xref="paper", yref="paper", showarrow=False,
                         text=("RandomForest on metadata & title components. Use 'Predicted vs Actual' to inspect fit. "
                               "Feature importances indicate which signals attract downloads (log scale)."),
                         font=dict(size=12, color="#dddddd"), align="left"))

# --------------------------
# Figure 3: Cross-source citation reconciliation
# --------------------------
fig3 = go.Figure()
aminer_vals = df["aminer"].fillna(0)
cross_vals = df["crossref"].fillna(0)
limmax = max(aminer_vals.max(), cross_vals.max(), 1.0)
lim_display = float(np.percentile(np.concatenate([aminer_vals, cross_vals]), 99.5) * 1.08)
lim_plot = max(1.0, min(limmax, lim_display))  # ensure not absurdly large

fig3.add_trace(go.Scatter(
    x=aminer_vals, y=cross_vals, mode="markers",
    marker=dict(size=7, color=df["Year"], colorscale="Turbo", showscale=True,
                colorbar=dict(title="Year", len=0.5, x=1.03)),
    text=df["Title"],
    hovertemplate="<b>%{text}</b><br>Aminer: %{x:.0f}<br>CrossRef: %{y:.0f}<extra></extra>",
    name="Aminer vs CrossRef"
))
fig3.add_trace(go.Scatter(x=[0, lim_plot], y=[0, lim_plot], mode="lines", line=dict(color="#00CC96"), name="Identity"))

# Bland-Altman (hidden)
fig3.add_trace(go.Scatter(
    x=df["citation_mean"], y=df["citation_diff"], mode="markers",
    marker=dict(size=7, color=df["cit_diff_outlier"].map({True: "#FF4136", False: "#0074D9"})),
    text=df["Title"],
    hovertemplate="<b>%{text}</b><br>Mean: %{x:.1f}<br>Diff (Aminer-CrossRef): %{y:.1f}<extra></extra>",
    visible=False,
    name="Bland-Altman"
))
# Mean and limits (hidden)
if not math.isnan(mean_diff) and not math.isnan(std_diff):
    fig3.add_trace(go.Scatter(x=[df["citation_mean"].min(), df["citation_mean"].max()],
                              y=[mean_diff, mean_diff], mode="lines",
                              line=dict(color="#FF851B", dash="dash"), visible=False, name="Mean diff"))
    fig3.add_trace(go.Scatter(x=[df["citation_mean"].min(), df["citation_mean"].max()],
                              y=[mean_diff + 1.96*std_diff, mean_diff + 1.96*std_diff], mode="lines",
                              line=dict(color="#B10DC9", dash="dot"), visible=False, name="+1.96 SD"))
    fig3.add_trace(go.Scatter(x=[df["citation_mean"].min(), df["citation_mean"].max()],
                              y=[mean_diff - 1.96*std_diff, mean_diff - 1.96*std_diff], mode="lines",
                              line=dict(color="#B10DC9", dash="dot"), visible=False, name="-1.96 SD"))

fig3.update_layout(
    updatemenus=[dict(
        type="buttons",
        direction="left",
        showactive=True,
        x=0.01, xanchor="left",
        y=1.26, yanchor="top",
        bgcolor="rgba(255,255,255,0.06)",
        bordercolor="#222222",
        pad={"r": 10, "t": 6},
        buttons=[
            dict(label="Scatter comparison",
                 method="update",
                 args=[{"visible": [True, True, False, False, False, False]}, {"title": "Aminer vs CrossRef — Scatter"}]),
            dict(label="Bland-Altman",
                 method="update",
                 args=[{"visible": [False, False, True, True, True, True]}, {"title": "Aminer vs CrossRef — Bland-Altman"}]),
        ]
    )]
)

fig3.update_layout(base_layout(title_text="3) Cross-source Citation Reconciliation", top_margin=200))
fig3.update_xaxes(title_text="Aminer citation count", range=[0, lim_plot])
fig3.update_yaxes(title_text="CrossRef citation count", range=[0, lim_plot])

fig3.add_annotation(dict(x=0.01, y=1.20, xref="paper", yref="paper", showarrow=False,
                         text=("Scatter: compare raw counts; Bland-Altman: mean vs difference to identify systematic bias/outliers."),
                         font=dict(size=12, color="#dddddd"), align="left"))

# --------------------------
# Figure 4: Metadata quality audit (bar + heatmap)
# --------------------------
fig4 = go.Figure()
fig4.add_trace(go.Bar(
    x=anomaly_counts.index[::-1],
    y=anomaly_counts.values[::-1],
    marker=dict(color=px.colors.qualitative.Plotly),
    name="Anomaly counts",
    hovertemplate="%{x}: %{y}<extra></extra>"
))

heat_z = pivot.values
heat_x = pivot.columns.tolist()
heat_y = pivot.index.tolist()
fig4.add_trace(go.Heatmap(
    z=heat_z, x=heat_x, y=heat_y, colorscale="Hot", showscale=True,
    visible=False, colorbar=dict(title="Count", x=1.12)
))

fig4.update_layout(
    updatemenus=[dict(
        type="buttons",
        direction="left",
        showactive=True,
        x=0.01, xanchor="left",
        y=1.26, yanchor="top",
        bgcolor="rgba(255,255,255,0.06)",
        bordercolor="#222222",
        pad={"r": 10, "t": 6},
        buttons=[
            dict(label="Anomaly counts (global)",
                 method="update",
                 args=[{"visible": [True, False]}, {"title": "Metadata Quality Audit — Anomaly counts"}]),
            dict(label="By Conference (heatmap)",
                 method="update",
                 args=[{"visible": [False, True]}, {"title": "Metadata Quality Audit — Top Conferences heatmap"}]),
        ]
    )]
)

fig4.update_layout(base_layout(title_text="4) Metadata Quality Audit & Anomalies", top_margin=200, right_margin=300))
fig4.update_xaxes(tickangle= -45)
fig4.add_annotation(dict(x=0.01, y=1.20, xref="paper", yref="paper", showarrow=False,
                         text=("Rules & z-score based anomalies: missing fields, inconsistent pages, and extreme metrics. "
                               "Use the heatmap to inspect which conferences have concentrated issues."),
                         font=dict(size=12, color="#dddddd"), align="left"))

# --------------------------
# Convert figures to HTML snippets (include_plotlyjs='cdn' inside each)
# --------------------------
figs = [fig1, fig2, fig3, fig4]
fig_html_snippets = [f.to_html(full_html=False, include_plotlyjs="cdn") for f in figs]

# --------------------------
# Build final HTML page (dark theme), with CSS and JS to:
# - ensure updatemenu buttons have readable hover/active style (light green)
# - remove tooltip/title attributes on Plotly buttons (so disappearing descriptions do not appear)
# - provide spacing so plotly controls don't overlap plot area
# - insert educational narratives (introduction, per-figure narratives, conclusion) with bold takeaways
# --------------------------
html_parts = []
html_parts.append("""<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Dataset Visualizations — Dark Theme (Educational Report)</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { background: #0b0f13; color: #e6eef3; font-family: Arial, Helvetica, sans-serif; margin: 20px; }
    h1.main-title { font-size: 34px; color: #FFFFFF; margin-bottom: 8px; }
    h2.section-title { font-size: 20px; color: #FFFFFF; margin: 6px 0 6px 0; }
    .plot-section { margin-bottom: 70px; padding: 18px; border-radius: 8px;
                    background: linear-gradient(180deg, rgba(255,255,255,0.01), rgba(255,255,255,0.02)); }
    .subtitle { color: #bfe6c7; font-size: 15px; margin-top: 6px; margin-bottom: 12px; }
    .narrative { color: #dfeef5; font-size: 16px; line-height: 1.6; margin-bottom: 12px; }
    .narrative strong { color: #ffffff; }
    .controls { display: flex; gap: 12px; align-items: center; margin-bottom: 12px; }
    .btn { padding: 9px 14px; border-radius: 6px; font-weight: 700; cursor: pointer; border: none; }
    .btn-primary { background: #FF5A5F; color: #040404; }
    .btn-secondary { background: #00CC96; color: #040404; }
    .btn-accent { background: #7FDBFF; color: #001f3f; }
    .btn:hover { filter: brightness(0.95); transform: translateY(-1px); }
    .spacer { height: 12px; }
    .fig-wrap { margin-top: 8px; }
    .note { color: #9fb3c8; font-size: 13px; margin-top: 8px; }
    /* Plotly updatemenu buttons override for readability and non-white hover */
    .js-plotly-plot button { background-color: rgba(255,255,255,0.04) !important; color: #e6eef3 !important; border: 1px solid rgba(255,255,255,0.03) !important; }
    .js-plotly-plot button:hover { background-color: #a8e6a1 !important; color: #000000 !important; }
    .js-plotly-plot button:active { background-color: #a8e6a1 !important; color: #000000 !important; }
    .modebar-btn { background: rgba(255,255,255,0.03) !important; }
  </style>
</head>
<body>
  <h1 class="main-title">Interactive Research Visualizations (Educational Report)</h1>
""")

# Introduction paragraph (flow + explanation of report and flow)
html_parts.append("""
  <div class="plot-section" style="background:transparent; padding:0; margin-bottom:16px;">
    <p class="narrative" style="font-size:17px;">
      Introduction — Purpose and Flow: This report explores the dataset of scientific publications using a set of
      lightweight but powerful data-science and statistical-learning methods. The purpose is to reveal signals about
      novelty, readership (downloads), citation consistency across sources, and metadata quality. The reader will see:
      (1) a semantic novelty analysis that connects innovation to citation rates; (2) a downloads-attraction model that
      explains which features predict reader interest; (3) a cross-source reconciliation comparing Aminer and CrossRef
      citation counts to find systematic differences; and (4) a metadata quality audit that flags anomalies. Each section
      contains an explanation of the algorithm used, why that algorithm was chosen, how to read the chart, and what
      meaningful findings would look like for someone with no specialized expertise. This introduction prepares you to
      move through the figures in order, from innovation signals to data-quality checks, and concludes with next-step ideas.
    </p>
  </div>
""")

# Section 1: Novelty narrative + chart
html_parts.append(f"""
  <div class="plot-section">
    <div style="display:flex; justify-content:space-between; align-items:flex-start;">
      <div>
        <div class="section-title">1) Topic-Innovation & Impact — Novelty vs Citations</div>
        <div class="subtitle">Semantic novelty (TF-IDF + SVD) vs citations per year. Color = downloads.</div>
      </div>
      <div style="text-align:right;">
        <button class="btn btn-primary" onclick="document.getElementById('fig1').scrollIntoView({{behavior:'smooth'}});">Go to chart</button>
      </div>
    </div>

    <p class="narrative">
      Algorithm & rationale: We use TF-IDF to convert paper titles and abstracts into numerical vectors and then apply
      Truncated SVD (a fast form of dimensionality reduction) to create compact semantic embeddings. We compute a
      <em>novelty score</em> by measuring how far each paper's embedding is from the centroid of papers published in the
      preceding three years. TF-IDF + SVD is chosen because it is fast, interpretable, and effective at capturing
      broad topical differences across thousands of documents without requiring heavy transformer models.
      The scatter plot maps novelty (x-axis) against citations per year (y-axis) and colors points by downloads.
    </p>

    <p class="narrative">
      How to read the chart and interpretation: The x-axis shows the normalized novelty score (0 = typical, 1 = very novel).
      The y-axis is citations per year, a simple rate that accounts for age. The colorbar shows Downloads (higher means more reader interest).
      If the trend line slopes upward, this suggests more novel papers receive more citations per year — a sign that novelty
      correlates with impact. Conversely, a flat or negative trend implies novelty alone does not drive citations.
      <strong>Main takeaway:</strong> <strong>if the plot shows a clear upward trend, it indicates that semantic novelty
      predicts faster citation accrual; if not, novelty may not translate directly to short-term citation impact.</strong>
      Typical/average outcomes: many papers cluster near low-to-moderate novelty and modest citation rates; extreme novelty with high citations is less common and therefore notable.
      This figure leads naturally to the next section: what drives reader attention (downloads), which we examine with a predictive model.
    </p>

    <div class="fig-wrap" id="fig1">{fig_html_snippets[0]}</div>
  </div>
""")

# Section 2: Downloads narrative + chart
html_parts.append(f"""
  <div class="plot-section">
    <div style="display:flex; justify-content:space-between; align-items:flex-start;">
      <div>
        <div class="section-title">2) Downloads Attraction Model — What draws readers?</div>
        <div class="subtitle">A RandomForest explains log(1 + Downloads) using title components and metadata.</div>
      </div>
      <div style="text-align:right;">
        <button class="btn btn-accent" onclick="document.getElementById('fig2').scrollIntoView({{behavior:'smooth'}});">Go to chart</button>
      </div>
    </div>

    <p class="narrative">
      Algorithm & rationale: We fit a Random Forest regressor to predict log(1 + downloads) because tree ensembles handle
      heterogenous data (numeric, categorical-encoded, and dense text features via SVD) and produce robust feature importance
      measures. This method was selected for its balance of performance and interpretability: it identifies which features
      drive predicted downloads and allows visual inspection of fit quality with a Predicted vs Actual view.
      The left view shows feature importances; the alternate view (use the in-chart dropdown) shows predicted vs actual log-downloads.
    </p>

    <p class="narrative">
      How to read and interpret results: In the Feature Importances view (default), each horizontal bar shows how much the model
      relied on that feature to explain variability in log-downloads. Larger importance implies stronger association with attracting readers.
      In Predicted vs Actual, points close to the diagonal indicate good predictions. <strong>Main takeaway:</strong>
      <strong>features with high importance (for example, citations per year, novelty, or certain title components) are strong signals
      of reader interest — if these are large, they meaningfully affect downloads.</strong>
      What counts as notable: a very high importance for novelty would mean that novelty attracts readers; high importance for early citations
      suggests social proof (citations) drives downloads. Typical models achieve modest R²; a low R² means downloads are noisy and driven by factors
      outside this dataset (social media, promotion).
      This section complements the novelty analysis by showing which signals best predict attention.
    </p>

    <div class="fig-wrap" id="fig2">{fig_html_snippets[1]}</div>
  </div>
""")

# Section 3: Cross-source reconciliation narrative + chart
html_parts.append(f"""
  <div class="plot-section">
    <div style="display:flex; justify-content:space-between; align-items:flex-start;">
      <div>
        <div class="section-title">3) Cross-Source Citation Reconciliation — Aminer vs CrossRef</div>
        <div class="subtitle">Scatter & Bland–Altman views reveal agreement or systematic offsets between sources.</div>
      </div>
      <div style="text-align:right;">
        <button class="btn btn-primary" onclick="document.getElementById('fig3').scrollIntoView({{behavior:'smooth'}});">Go to chart</button>
      </div>
    </div>

    <p class="narrative">
      Algorithm & rationale: This section uses descriptive analytic plots rather than a complex learning algorithm. The scatter plot
      compares citation counts from two sources — Aminer and CrossRef — to see overall agreement. The Bland–Altman plot (mean vs difference)
      is a standard method to detect systematic bias between two measurement sources. We chose these visualizations because they quickly
      highlight whether one source consistently reports higher or lower counts and where disagreements concentrate (for example, on older vs newer papers).
    </p>

    <p class="narrative">
      How to read the chart and what to look for: In the scatter, points on the diagonal indicate agreement. A wide spread perpendicular
      to the diagonal indicates discrepancy. The Bland–Altman view plots the average citation count on the x-axis and the difference
      (Aminer − CrossRef) on the y-axis; horizontal lines show mean difference and ±1.96 standard deviations. <strong>Main takeaway:</strong>
      <strong>If Bland–Altman shows a mean far from zero, the sources are systematically biased; many points outside ±1.96 SD indicate inconsistent records.</strong>
      Typical/average: small mean differences around zero and most points within ±1.96 SD indicate acceptable variation. Large systematic differences suggest the need for calibration or preferring one source for downstream analyses.
      The reconciliation informs which citation column to trust for impact measures and guides the composite impact index discussed in the conclusion.
    </p>

    <div class="fig-wrap" id="fig3">{fig_html_snippets[2]}</div>
  </div>
""")

# Section 4: Metadata audit narrative + chart
html_parts.append(f"""
  <div class="plot-section">
    <div style="display:flex; justify-content:space-between; align-items:flex-start;">
      <div>
        <div class="section-title">4) Metadata Quality Audit & Anomalies</div>
        <div class="subtitle">Rule-based checks and z-score anomalies flag missing fields, page inconsistencies, and extremes.</div>
      </div>
      <div style="text-align:right;">
        <button class="btn btn-accent" onclick="document.getElementById('fig4').scrollIntoView({{behavior:'smooth'}});">Go to chart</button>
      </div>
    </div>

    <p class="narrative">
      Algorithm & rationale: This audit uses simple deterministic rules (e.g., LastPage < FirstPage, missing DOI, missing abstract)
      and statistical anomaly detection using z-scores for downloads and citations. These lightweight checks were chosen because
      metadata errors are common and can bias analyses; they are fast and reliable for triaging data cleaning priorities.
      The first view shows global anomaly counts; the heatmap view breaks anomalies down by top conferences so you can spot concentrated issues.
    </p>

    <p class="narrative">
      How to interpret and what is significant: Records flagged for missing DOI or LastPage < FirstPage often need manual correction.
      Extreme z-scores for downloads or citations (beyond ±3) indicate outliers that may be valid (very highly cited) or artifacts (spam, aggregation errors).
      <strong>Main takeaway:</strong> <strong>High counts of rule-based errors or clustered problems in a specific conference indicate targeted cleaning efforts will substantially improve downstream modeling.</strong>
      Typical: a clean dataset will have few rule-based flags and only a handful of extreme z-score outliers. Use these findings to prioritize fixing DOIs, page range parsing, and verifying unusually high metrics.
    </p>

    <div class="fig-wrap" id="fig4">{fig_html_snippets[3]}</div>
  </div>
""")

# Conclusion paragraph
html_parts.append("""
  <div class="plot-section" style="background:transparent; padding:0; margin-top:6px;">
    <p class="narrative" style="font-size:17px;">
      Conclusion — Key points and next steps: This educational report combined semantic-text features, a lightweight supervised model,
      and descriptive reconciliation and audit techniques to address several practical research questions. We found that semantic novelty
      is measurable with TF-IDF + SVD and can be related to citation rates; Random Forests provide insight into which features predict downloads;
      Bland–Altman analysis helps detect systematic differences between citation sources; and simple rule-based audits effectively surface
      metadata problems. <strong>Next steps</strong> for research scientists include: (1) applying more advanced text embeddings (e.g., SciBERT)
      to refine novelty and topic analysis; (2) expanding models to multi-task frameworks to jointly predict downloads and citations; (3)
      performing causal or survival analyses for long-term citation trajectories; and (4) correcting metadata issues and re-evaluating model performance.
      <strong>Main concluding takeaway:</strong> <strong>Combining interpretable text-derived features with robust, time-aware validation and careful metadata auditing yields practical, actionable insights into research impact and data quality.</strong>
    </p>
  </div>
""")

# Footer notes + small JS to remove disappearing descriptions from plotly updatemenu buttons
html_parts.append("""
  <div style="height:8px;"></div>
  <div style="color:#9fb3c8; font-size:13px;">
    <strong>Technical notes:</strong> Numeric NaNs were median-imputed; text NaNs set to empty strings. Novelty uses TF-IDF + SVD relative to prior 3 years.
    The Downloads model uses RandomForest because of its robustness with mixed features and its clear feature importance outputs. Visual controls are placed to avoid overlap.
  </div>

  <script>
    // Wait a bit for Plotly elements to render, then remove title attributes (these create the disappearing descriptions)
    window.addEventListener('load', function() {
      setTimeout(function() {
        document.querySelectorAll('.js-plotly-plot button').forEach(function(b) {
          try { b.removeAttribute('title'); } catch(e) {}
        });
        var style = document.createElement('style');
        style.innerHTML = ".js-plotly-plot button:hover { background-color: #a8e6a1 !important; color: #000 !important; } .js-plotly-plot button:active { background-color: #a8e6a1 !important; color: #000 !important; }";
        document.head.appendChild(style);
      }, 300);
    });
  </script>

</body>
</html>
""")

full_html = "\n".join(html_parts)

with open("output.html", "w", encoding="utf-8") as f:
    f.write(full_html)

print("Generated 'output.html' with narratives. Open it in a browser to view the interactive educational report.")

