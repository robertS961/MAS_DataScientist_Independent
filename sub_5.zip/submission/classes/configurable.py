
from typing_extensions import TypedDict

class Configurable(TypedDict):
    tread_id: int
    recursion_limit: int