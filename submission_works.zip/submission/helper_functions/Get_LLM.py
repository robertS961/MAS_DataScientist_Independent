import os

from langchain_openai import ChatOpenAI, AzureChatOpenAI
from openai import OpenAI, AzureOpenAI

from dotenv import load_dotenv
load_dotenv()     

def get_llm(**kw):
    """
    Return a Chat‑compatible LLM whose backend (OpenAI, Azure, local stub…)
    is selected by env‑vars.  Extra **kw flow through so nodes can override
    temperature, max_tokens, etc. without knowing the backend.

    Mini challenge evaluation server uses azure openai to run your submission.
    You don't need to fill in the azure openai endpoint and api key, 
    but you need to fill in the openai api key and model name to run locally.
    """
    provider = os.getenv("LLM_PROVIDER", "openai")

    if provider.lower() == "azure":
        model_name = kw.get('model', "gpt-4o")
        return AzureChatOpenAI(
            azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
            api_key       =os.environ["AZURE_OPENAI_API_KEY"],
            deployment_name=model_name,
            api_version   =os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),
            **kw,
        )
    elif provider.lower() == "local-echo":
        from langchain.llms.fake import FakeListLLM
        return FakeListLLM(responses=["This is a stub."])  
    else:
        model_name = kw.get('model', os.getenv("OPENAI_MODEL", "gpt-4o"))  
        return ChatOpenAI(
            api_key =os.getenv("OPENAI_API_KEY"),
            model_name=model_name,
            **kw,
        )